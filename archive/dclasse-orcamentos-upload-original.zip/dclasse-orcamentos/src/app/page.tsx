export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 p-8">
      <h1 className="text-2xl font-semibold">D&apos;Classe Papéis — Orçamentos</h1>
      <p className="text-gray-600">
        Estrutura inicial do projeto. Próximo passo: tela de identificação do
        representante (nome) e listagem/cadastro de clientes.
      </p>
    </main>
  );
}
