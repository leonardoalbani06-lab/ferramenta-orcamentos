import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "D'Classe Papéis | Orçamentos",
  description: "Ferramenta interna para representantes montarem orçamentos",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  );
}
